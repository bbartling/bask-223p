-- PostgreSQL adaptation. Render numeric template parameters with render_rule.py.
-- Sensor-series input and output are keyed by the bound point UUID, not the role.
WITH rp AS (
  -- Run proof (#1608): the input role run_proof is resolved from the model (own status, own command, feeding equipment).
  -- With the gate on and no proof bound at all, the equipment is SKIPPED: fault_hours NULL, covered_hours 0.
  SELECT equipment_id,
    CASE WHEN {{REQUIRE_RUN_PROOF}} >= 0.5 AND COUNT(run_proof) = 0 THEN 1 ELSE 0 END AS no_run_proof
  FROM history
  GROUP BY equipment_id
),
base_proof AS (
  SELECT h.*,
    CASE WHEN {{REQUIRE_RUN_PROOF}} < 0.5 THEN 1 WHEN h.run_proof > 0.05 THEN 1 ELSE 0 END AS energized
  FROM history h
),
equipment_summary AS (
  SELECT equipment_id,
    MAX(EXTRACT(EPOCH FROM timestamp_utc)) AS observed_end_epoch,
    100.0 * AVG(energized) AS coverage_pct
  FROM base_proof
  GROUP BY equipment_id
),
sensor_series AS (
  SELECT equipment_id, series_id, sensor_role
  FROM sensor_history
  WHERE sensor_role IN ({{ASSESSABLE_ROLES}})
  GROUP BY equipment_id, series_id, sensor_role
),
-- #1631: bounded as-of proof per (equipment, sample time) with window functions (no correlated subquery, so it scales on
-- PostgreSQL / TimescaleDB): proof rows and the distinct sample times of one equipment are interleaved in time order
-- (a proof row sorts before a sample at the same instant); a running count of proof rows tags every sample with the
-- latest proof row at or before it; that row's proof is used when it is less than MAX_GAP_HOURS older than the sample.
sample_times AS (
  SELECT DISTINCT equipment_id, timestamp_utc, EXTRACT(EPOCH FROM timestamp_utc) AS epoch_seconds
  FROM sensor_history
  WHERE value IS NOT NULL
    AND sensor_role IN ({{ASSESSABLE_ROLES}})
),
proof_stream AS (
  SELECT equipment_id, timestamp_utc, EXTRACT(EPOCH FROM timestamp_utc) AS epoch_seconds, 0 AS stream_kind, energized
  FROM base_proof
  UNION ALL
  SELECT equipment_id, timestamp_utc, epoch_seconds, 1 AS stream_kind, NULL AS energized
  FROM sample_times
),
proof_tagged AS (
  SELECT proof_stream.*,
    SUM(CASE WHEN stream_kind = 0 THEN 1 ELSE 0 END)
      OVER (PARTITION BY equipment_id ORDER BY epoch_seconds, stream_kind ROWS UNBOUNDED PRECEDING) AS proof_group
  FROM proof_stream
),
proof_carried AS (
  SELECT proof_tagged.*,
    MAX(CASE WHEN stream_kind = 0 THEN epoch_seconds END) OVER (PARTITION BY equipment_id, proof_group) AS proof_epoch,
    MAX(CASE WHEN stream_kind = 0 THEN energized END) OVER (PARTITION BY equipment_id, proof_group) AS proof_energized
  FROM proof_tagged
),
proof_asof AS (
  SELECT equipment_id, timestamp_utc,
    CASE WHEN proof_epoch IS NOT NULL AND proof_epoch > epoch_seconds - {{MAX_GAP_HOURS}} * 3600.0
      THEN proof_energized ELSE NULL END AS energized
  FROM proof_carried
  WHERE stream_kind = 1
),
sensor_rows AS (
  SELECT s.equipment_id, s.series_id, s.sensor_role, s.timestamp_utc,
    CASE WHEN hs.observed_end_epoch IS NULL OR MAX(EXTRACT(EPOCH FROM s.timestamp_utc)) OVER (PARTITION BY s.equipment_id) > hs.observed_end_epoch
      THEN MAX(EXTRACT(EPOCH FROM s.timestamp_utc)) OVER (PARTITION BY s.equipment_id) ELSE hs.observed_end_epoch END AS observed_end_epoch,
    -- #1631: the proof of a sample is the latest proof row at or before it, held for at most MAX_GAP_HOURS (proof_asof).
    -- No such row (or a NULL proof) is UNKNOWN: it cannot create a fault. With the gate off every sample is eligible.
    COALESCE(pa.energized, CASE WHEN {{REQUIRE_RUN_PROOF}} < 0.5 THEN 1 ELSE 0 END) AS energized,
    COALESCE(hs.coverage_pct, 100.0) AS coverage_pct,
    EXTRACT(EPOCH FROM s.timestamp_utc) AS epoch_seconds,
    fdd.mask_sweep_val(s.sensor_role, s.unit, s.value) AS value
  FROM sensor_history s
  LEFT JOIN equipment_summary hs
    ON hs.equipment_id = s.equipment_id
  LEFT JOIN proof_asof pa
    ON pa.equipment_id = s.equipment_id AND pa.timestamp_utc = s.timestamp_utc
  WHERE s.value IS NOT NULL
    AND s.sensor_role IN ({{ASSESSABLE_ROLES}})
),
prior AS (
  SELECT sensor_rows.*,
    LAG(value) OVER (PARTITION BY equipment_id, series_id ORDER BY epoch_seconds) AS previous_value,
    COALESCE(LEAD(epoch_seconds) OVER (PARTITION BY equipment_id, series_id ORDER BY epoch_seconds), observed_end_epoch) AS next_epoch,
    LAG(epoch_seconds) OVER (PARTITION BY equipment_id, series_id ORDER BY epoch_seconds) AS previous_epoch
  FROM sensor_rows
),
prior_groups AS (
  SELECT prior.*,
    SUM(CASE WHEN value IS NULL OR previous_value IS NULL OR previous_epoch IS NULL
                  OR epoch_seconds - previous_epoch > {{MAX_GAP_HOURS}} * 3600.0
             THEN 1 ELSE 0 END)
      OVER (PARTITION BY equipment_id, series_id ORDER BY epoch_seconds ROWS UNBOUNDED PRECEDING) AS data_segment
  FROM prior
),
valid AS (
  SELECT * FROM prior_groups WHERE value IS NOT NULL
),
rates AS (
  SELECT valid.*,
    (epoch_seconds - previous_epoch) / 3600.0 AS dt_hours,
    ABS(value - previous_value) AS delta
  FROM valid
),
flagged AS (
  SELECT rates.*,
    CAST(CASE
      WHEN previous_epoch IS NULL OR epoch_seconds - previous_epoch > {{MAX_GAP_HOURS}} * 3600.0 THEN 0
      WHEN dt_hours IS NULL OR dt_hours <= 0.0 THEN 0
      WHEN delta / dt_hours > {{SV_RATE_THRESHOLD}} THEN 1
      ELSE 0
    END AS INT) AS over_rate
  FROM rates
),
lagged AS (
  SELECT flagged.*,
    COALESCE(LAG(over_rate) OVER (PARTITION BY equipment_id, series_id ORDER BY epoch_seconds), 0) AS previous_over_rate
  FROM flagged
),
base AS (
  SELECT lagged.*,
    CAST(CASE WHEN over_rate = 1 AND previous_over_rate = 1 AND energized = 1 THEN 1 ELSE 0 END AS INT) AS raw_fault,
    CASE WHEN next_epoch IS NULL OR next_epoch <= epoch_seconds THEN 0.0
         WHEN next_epoch - epoch_seconds > {{MAX_GAP_HOURS}} * 3600.0 THEN 0.0
         ELSE next_epoch - epoch_seconds END AS held_seconds
  FROM lagged
),
streak_groups AS (
  SELECT base.*,
    COALESCE(LAG(raw_fault) OVER (PARTITION BY equipment_id, series_id ORDER BY epoch_seconds), 0) AS previous_raw_fault
  FROM base
),
streaks AS (
  SELECT streak_groups.*,
    SUM(CASE WHEN (raw_fault = 1 AND previous_raw_fault = 0) OR raw_fault = 0
             THEN 1 ELSE 0 END) OVER (
      PARTITION BY equipment_id, series_id, data_segment ORDER BY epoch_seconds ROWS UNBOUNDED PRECEDING
    ) AS streak_group
  FROM streak_groups
),
confirmed_rows AS (
  SELECT streaks.*,
    SUM(CASE WHEN raw_fault = 1 THEN held_seconds ELSE 0.0 END) OVER (
      PARTITION BY equipment_id, series_id, data_segment, streak_group
      ORDER BY epoch_seconds ROWS UNBOUNDED PRECEDING
    ) AS fault_streak_seconds
  FROM streaks
),
final AS (
  SELECT equipment_id, series_id, sensor_role, epoch_seconds AS segment_epoch,
    CASE WHEN raw_fault = 1 AND fault_streak_seconds >= {{CONFIRM_SECONDS}} THEN 1 ELSE 0 END AS confirmed,
    held_seconds
  FROM confirmed_rows WHERE held_seconds > 0
),
scored AS (
  SELECT equipment_id, series_id, sensor_role,
    SUM(CASE WHEN confirmed = 1 THEN held_seconds ELSE 0.0 END) / 3600.0 AS fault_hours,
    SUM(held_seconds) / 3600.0 AS covered_hours
  FROM final
  GROUP BY equipment_id, series_id, sensor_role
)
SELECT ss.equipment_id, ss.series_id, ss.sensor_role,
  CASE WHEN COALESCE((SELECT rpx.no_run_proof FROM rp rpx WHERE rpx.equipment_id = ss.equipment_id), CASE WHEN {{REQUIRE_RUN_PROOF}} >= 0.5 THEN 1 ELSE 0 END) = 1 THEN NULL ELSE CASE WHEN COALESCE(scored.covered_hours, 0.0) > 0 THEN COALESCE(scored.fault_hours, 0.0) ELSE NULL END END AS fault_hours,
  CASE WHEN COALESCE((SELECT rpx.no_run_proof FROM rp rpx WHERE rpx.equipment_id = ss.equipment_id), CASE WHEN {{REQUIRE_RUN_PROOF}} >= 0.5 THEN 1 ELSE 0 END) = 1 THEN 0.0 ELSE COALESCE(scored.covered_hours, 0.0) END AS covered_hours
FROM sensor_series ss
LEFT JOIN scored USING (equipment_id, series_id, sensor_role)
ORDER BY ss.equipment_id, ss.series_id;
