# Dialect notes

The bundle ships **every** SQL file under `sql/` (fault rules and analytics), the rendered PostgreSQL pack (`pack/pack-postgres.json`, one entry per registry rule), and `sql/fdd/schema/core.sql`.

Scratch tables the fault rules read: `history` (wide, one row per equipment and timestamp), `sensor_history`, `weather`, `sweep_series`, `utility_monthly`, `utility_interval`. Values are SI. `confirm_min` is the only host-facing tuner (default 15 minutes). Other delays are constants already rendered into the pack.

| Engine | Notes |
| --- | --- |
| postgres | Native. Install `sql/fdd/postgres/postgres_helpers.sql` once. |
| timescale | Same SQL as postgres. Hypertables are optional and are not in this bundle. |
| sqlite | Same scratch tables. `EXTRACT(EPOCH FROM interval)` and `to_char` need the same rewrites as DuckDB. |
| duckdb | Run with `SET autoinstall_known_extensions = false`. Create the macros in `scripts/release/duckdb_runner.py` (`fdd.try_double`, `fdd.mask_sweep_val`, `to_char`) before executing the pack. No network and no extension install. |
