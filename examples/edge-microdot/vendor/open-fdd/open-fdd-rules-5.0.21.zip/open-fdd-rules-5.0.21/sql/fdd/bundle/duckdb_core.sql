-- Portable core for hosts that store samples in DuckDB (edge, notebooks).
-- PostgreSQL hosts use sql/fdd/schema/core.sql instead.
-- autoinstall_known_extensions must stay false for offline runs.

CREATE SCHEMA IF NOT EXISTS fdd;

CREATE TABLE IF NOT EXISTS fdd.point (
  site_id VARCHAR NOT NULL,
  point_key VARCHAR NOT NULL,
  equipment_id VARCHAR,
  role VARCHAR,
  unit VARCHAR,
  PRIMARY KEY (site_id, point_key)
);

CREATE TABLE IF NOT EXISTS fdd.input_sample (
  site_id VARCHAR NOT NULL,
  point_key VARCHAR NOT NULL,
  ts TIMESTAMP NOT NULL,
  value DOUBLE
);

CREATE TABLE IF NOT EXISTS fdd.rule_result (
  site_id VARCHAR NOT NULL,
  equipment_id VARCHAR NOT NULL,
  rule_id VARCHAR NOT NULL,
  subject_key VARCHAR NOT NULL DEFAULT '',
  window_start TIMESTAMP NOT NULL,
  window_end TIMESTAMP NOT NULL,
  status VARCHAR NOT NULL,
  reason VARCHAR,
  fault_hours DOUBLE,
  covered_hours DOUBLE,
  confirm_min DOUBLE NOT NULL DEFAULT 15
);

CREATE TABLE IF NOT EXISTS fdd.rule_config (
  site_id VARCHAR NOT NULL,
  rule_id VARCHAR NOT NULL,
  confirm_min DOUBLE NOT NULL DEFAULT 15,
  active BOOLEAN NOT NULL DEFAULT true,
  PRIMARY KEY (site_id, rule_id)
);
